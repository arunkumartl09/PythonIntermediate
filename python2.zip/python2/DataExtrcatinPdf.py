#!/usr/bin/env python
# coding: utf-8

# In[36]:


import pdfplumber

from fpdf import FPDF

inv = pdfplumber.open("C:\\Users\DELL\Desktop\Python+Kotlin\\inv.pdf")

data = inv.pages[0]

text = data.extract_text()

pdf = FPDF()

pdf.add_page()

pdf.set_font("Arial",size=10)

pdf.multi_cell(0,5, txt=text)

pdf.output("C:\\Users\DELL\Desktop\\invoice.pdf")



# In[32]:


import pdfplumber

from fpdf import FPDF

import pandas as pd

inv = pdfplumber.open("C:\\Users\DELL\Desktop\Python+Kotlin\\inv.pdf")

data = inv.pages[0]

table = data.extract_tables()

for i in range(len(table[1])):
    if "Invoice Number" in table[1][i]:
        inv_num = table[1][0][1]
    if "Order Number" in table[1][i]:
        ord_num = table[1][1][1]
    if "Invoice Date" in table[1][i]:
        inv_date = table[1][2][1]
    if "Due Date" in table[1][i]:
        due_date = table[1][3][1]
    if "Total Due" in table[1][i]:
        total_due = table[1][4][1]

req_data = {"Invoice Number":inv_num,
           "Order Number":ord_num,
           "Invoice Date":inv_date,
           "Due Date":due_date,
           "Total Due":total_due,
           "index":[1]}

print(req_data)

df = pd.DataFrame(req_data)

df.to_html("C:\\Users\DELL\Desktop\\invoice.html")

    
    
    
        

        


# In[62]:


import pdfplumber

import pandas as pd

inv = pdfplumber.open("C:\\Users\DELL\Desktop\Python+Kotlin\\inv.pdf")

data = inv.pages[0]

text = data.extract_text().splitlines()



for line in text:
    if "invoice number" in line.lower():
        inv_num=(line.split()[2])
    if "order number" in line.lower():
        ord_num=(line.split()[6])
    if "due date" in line.lower():
        due_date = (line.split("Due Date")[1].strip())
    if "total due" in line.lower():
        total_due = (line.split()[2])
    if "invoice date" in line.lower():
        inv_date = (line.split("Invoice Date")[1].strip())

req_data = {"Invoice Number":inv_num,
           "Order Number":ord_num,
           "Invoice Date":inv_date,
           "Due Date":due_date,
           "Total Due":total_due,
           "index":[1]}
print(req_data)
  


# In[ ]:




