#!/usr/bin/env python
# coding: utf-8

# In[10]:


import matplotlib.pyplot as plt

names = ["arun", "lokesh", "vamshi","manu"]

salary = [4,5,6,7] # at the time of joining company

sal =[ 20, 25, 26, 27]  # hike of salary after 5 years


#plt.plot(names, salary) to plot in x axis and y axis

plt.plot(names,salary, "og") #"og" means circle with color green

plt.plot(names,sal,"oy")

plt.title("Employees with Salary") # add title to the plot

plt.xlabel("Names")               # add x label to the plot

plt.ylabel("Salary")

#plt.axis([xmin,xmax,ymin,yamax])

plt.savefig("C:\\Users\DELL\Desktop\\Sal1.png") #to save image file in system


plt.show()


# In[18]:


fig_1 = plt.figure(1, figsize=[15,5])

chart_1 = fig_1.add_subplot(121)  # 121 means 1=one row, 2=number of plots, 2 plots , 1 =positon of that plot

chart_2 = fig_1.add_subplot(122)

chart_1.plot(names,salary,"or")

chart_1.set_title("Employees with salary")

chart_1.set_xlabel("names")

chart_1.set_ylabel("salary")

chart_2.plot(names,sal,"ob")

chart_2.set_title("Employees with salary")

chart_2.set_xlabel("names")

chart_2.set_ylabel("salary")

plt.show()


# In[33]:


names = ["arun","lokesh", "vamshi","mahesh","manu"]

years= [1995,1994,1996,1997,1993]

ages = [27,25,24,23,21]


fig_2 = plt.figure(1, figsize=[15,5])

chart_3 = fig_2.add_subplot(121)  # 121 means 1=one row, 2=number of plots, 2 plots , 1 =positon of that plot

chart_4 = fig_2.add_subplot(122)

chart_3.plot(names,years,"or")

chart_4.plot(names,ages,"oy")


chart_3.set_title("Names with Birth year")

chart_3.set_xlabel("names")

chart_3.set_ylabel("years")

chart_3.axis([-1,4,1992,1998]) # limiting x-axis and y-axis values. Syntax plt.axis([xmin,xmax,ymin,ymax])


chart_4.set_title("Names with present age")

chart_4.set_xlabel("names")

chart_4.set_ylabel("age")

plt.show()



# In[41]:


fig_2, axes = plt.subplots(1,2,figsize=[15,5])    #second way of subplotting 

axes[0].plot(names,ages,"oy")                    # axes works as a list
axes[1].plot(names,ages,"or")


plt.show()


# In[75]:


# Bar representation

# plt.bar(x,y(height), width=0.4, bottom=None, align="center", data=None, kwargs="key word arguments")

names =["arun", "mahesh", "lokesh","manu"]

eff = [92, 91, 94, 97]

std=[56,76,89,95]

w =[0.4,0.3,0.5,0.2]

c=["red","green","yellow","orange"]

c1= ["blue","yellow","red","green"]

plt.bar(names, eff, width=w, color=c, label="ex one")

plt.bar(names, std,align="edge",width=w, color=c1, label="ex two")

plt.legend()

plt.show()


# In[ ]:





# In[74]:


# pie chart

# i have salary 25,000
# food = 7,000
# rent = 5,000
# automobiles = 3000
# savings = 10,000

spent_values = [7000,5000,3000,10000]

spent_labels = ["food","rent","automobiles","savings"]

plt.pie(spent_values, labels = spent_labels, autopct = "%0.00f%%", explode = [0,0,0,0.2], radius=1)



plt.show()


# In[ ]:




