#Reading textfile from the system
arun=open("C:\\Users\DELL\Desktop\\arun.txt","r") #Feed the path of the file to open

for line in arun:                                 #readiing each line in text file
    print(line,end='')

with open("C:\\Users\DELL\Desktop\\arun.txt","r") as arun:
   line=arun.readline()                                    #readline is a method which gives one line
   while line:
       print(line,end='')
       line=arun.readline()

with open("C:\\Users\DELL\Desktop\\arun.txt","r") as arun:
    lines=arun.readlines()                                 #readlines is amethod which reads all lines
print(lines)




