#!/usr/bin/env python
# coding: utf-8

# In[48]:


import pdfplumber

inv = pdfplumber.open("C:\\Users\DELL\Desktop\Python+Kotlin\\DataAnalysis.pdf")

data = inv.pages[0]

text = data.extract_tables()

purchased = (text[0:1])

sold = (text[1:2])

Bought_prices = []

Bought_item_quantity = []

Bought_items = ["Monitor","Keyboard","CPU","Printer"]

for i in range(len(purchased)):
    for data in purchased[i]:
        if "Monitor" in data:
            mp = (int(data[2].split()[0].replace(",","")))
            Bought_prices.append(mp)
            mq = (int(data[1]))
            Bought_item_quantity.append(mq)
        
        if "Keyboard" in data:
            kp = (int(data[2].split()[0].replace(",","")))
            Bought_prices.append(kp)
            kq = (int(data[1]))
            Bought_item_quantity.append(kq)
            
        if "CPU" in data:
            cp = (int(data[2].split()[0].replace(",","")))
            Bought_prices.append(cp)
            cq = (int(data[1]))
            Bought_item_quantity.append(cq)
            
        if "Printer" in data:
            pp = (int(data[2].split()[0].replace(",","")))
            Bought_prices.append(pp)
            pq = (int(data[1]))
            Bought_item_quantity.append(pq)

print(Bought_items)
print(Bought_prices)
print(Bought_item_quantity)

individual_price_b = []

for i in range(len(Bought_prices)):
    k = Bought_prices[i]//Bought_item_quantity[i]
    individual_price_b.append(k)
print(individual_price_b)

#################################################################################################################################

Sold_prices = []

Sold_item_quantity = []

Sold_items = ["Monitor","Keyboard","CPU","Printer"]

for i in range(len(sold)):
    for data in sold[i]:
        if "Monitor" in data:
            mp = (int(data[2].split()[0].replace(",","")))
            Sold_prices.append(mp)
            mq = (int(data[1]))
            Sold_item_quantity.append(mq)
        
        if "Keyboard" in data:
            kp = (int(data[2].split()[0].replace(",","")))
            Sold_prices.append(kp)
            kq = (int(data[1]))
            Sold_item_quantity.append(kq)
            
        if "CPU" in data:
            cp=(int(data[2][0:8].replace(",","")))
            Sold_prices.append(cp)
            cq = (int(data[1]))
            Sold_item_quantity.append(cq)
            
        if "Printer" in data:
            pp = (int(data[2].split()[0].replace(",","")))
            Sold_prices.append(pp)
            pq = (int(data[1]))
            Sold_item_quantity.append(pq)
            
print(Sold_items)
print(Sold_prices)
print(Sold_item_quantity)

individual_price_s = []

for i in range(len(Sold_prices)):
    k = Sold_prices[i]//Sold_item_quantity[i]
    individual_price_s.append(k)
    
print(individual_price_s)

profit_loss = []

for i in range(len(individual_price_s)):
    p = individual_price_s[i] - individual_price_b[i]
    
    profit_loss.append(p)
    
    
print(profit_loss)

data = {"items":Bought_items,
       "Bought price":Bought_prices,
       "Bought Quantity":Bought_item_quantity,
       "Individual Price Bought":individual_price_b,
       "Sold Price":Sold_prices,
       "Sold QUantity":Sold_item_quantity,
       "Individual Price Sold":individual_price_s,
       "Profit or loss":profit_loss
       }

import pandas as pd

df = pd.DataFrame(data, index = [1,2,3,4])

df.to_html("Systems.html")


# In[ ]:




