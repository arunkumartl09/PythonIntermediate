#Writing text into a text file
cities=["Tumkur","Mysore","Bengaluru"]    #list of cities

with open("cities.txt","w") as city_file:  #consideirng cities.txt as text file
    for city in cities:
        print(city,file=city_file)         #storing each city in city_file

places=[]
with open("cities.txt","r") as arun:      #reading text file that stored
    for line in arun:
        places.append(line.strip())       #storing ech line in list and removing enod of line '\n' with strip
print(places)

KGF= "Neel","Yash","2016",(
    (1,"It was a good movie"),                 #Storing data inside a tuple
    (2,"best actor Yash")
)

with open("kgf.txt","w") as kgf_file:
    print(KGF,file=kgf_file)                   #Writing data into a kgf_file

with open("kgf.txt","r") as arun:             #Opening kgf.txt file as arun
    lines=arun.readline()                     # reading each lines
kmf=eval(lines)                               # Evaluating lines
print(kmf)