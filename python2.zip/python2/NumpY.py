#!/usr/bin/env python
# coding: utf-8

# In[1]:


import sys

a = [3,4,5,6,7,8]

print(type(a))

print(sys.getsizeof(a))


# In[2]:


# getting attributes according to the numpy array

import numpy as np

b = np.array([1,4,5,6,7,9])

print(b)

print(b.size)

print(b.dtype)

print(b.nbytes)

print(b.ndim)

print(b.itemsize)

print(b.shape)


# In[3]:


# two dimensional array
c = np.array([[1,2,3,4],[4,5,6,7]])

print(c)

print(c.shape)

print(c.size)

print(c.ndim)

print(c.nbytes)

print(c.itemsize)


# In[4]:


#mathematical operations
d = np.array([4,5,6,7])
g=np.array([17,68,89,94])

p = d+g

k= d*g

t = d -g

h = d*12

print(p)

print(k)

print(t)

print(h)


# In[5]:


# assigning and Slicing
import numpy as np

n = np.array([4,5,6,7])

n[0] = 8

print(n)

t = list(map(int,input().strip().split()))

y=[]

y.append(9)

r = np.array(t)

print(b)


# In[13]:


import numpy as np
m = np.array([1,2,3,4,5])

print(m[2:4])

print(m[1:])

print(m[:1])

print(m[:-1])


# In[25]:


d = np.array([[4,5,6,7],[7,8,3,4]])

print(d)

print(d[1,2])

print(d[0,1])

print(d[:,2])

print(d[1,:])


# In[ ]:


1 1 1 1 1
1 0 0 0 1
1 0 0 0 1
1 0 8 0 1
1 1 1 1 1

