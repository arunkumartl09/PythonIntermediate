import PyPDF2

import pdfplumber

inv=pdfplumber.open("C:\\Users\DELL\Desktop\Python+Kotlin\\inv.pdf")

pages=inv.pages[0]

data=pages.extract_text()

kumar=PyPDF2.PdfFileWriter()






